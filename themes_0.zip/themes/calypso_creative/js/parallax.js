(function ($, Drupal){
    // 'use strict';
    Drupal.behaviors.myBehavior = {
        attach: function (context, settings) {

            var controller = new ScrollMagic.Controller({globalSceneOptions: {triggerHook: "onEnter", duration: "150%"}});

            var scene1 = new ScrollMagic.Scene({
                        triggerElement: '.parallax--parallax01',
                        triggerHook: 1,
                        })
                        
            .setTween(TweenMax.from('.parallax--parallax01 .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene2 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxblog',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxblog .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene3 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxcontact',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxcontact .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene4 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxinstudio',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxinstudio .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene5 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxabout',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxabout .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene6 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxservices',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxservices .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);

            var scene7 = new ScrollMagic.Scene({
                triggerElement: '.parallax--parallaxportfolio',
                triggerHook: 1,
                })
                
             .setTween(TweenMax.from('.parallax--parallaxportfolio .parallax__bg', 1, {y: '-50%', ease: Linear.easeNone}))
            .addTo(controller);
        }
    };
}(jQuery, Drupal));