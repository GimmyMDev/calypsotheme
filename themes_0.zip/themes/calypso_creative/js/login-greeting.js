(function ($, Drupal) {

  var myDate = new Date();
  var hrs = myDate.getHours();
  var greet;
  var text;

  if (hrs < 12) {
    greet = 'Good morning :)';
    text = "Let's kick ass today";
  } else if (hrs >= 12 && hrs <= 17) {
    greet = 'Good afternoon :)';
    text = 'You did good today';
  } else if (hrs >= 17 && hrs <= 24) {
    greet = 'Good evening :)';
    text = 'Stop working!'
  }

  document.getElementById('login-greeting-heading').textContent = greet;
  document.getElementById('login-greeting-text').textContent = text;

})(jQuery, Drupal);
