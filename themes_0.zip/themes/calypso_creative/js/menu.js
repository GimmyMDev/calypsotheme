(function ($, Drupal){
    $(function () {
        $(document).scroll(function () {
            var $nav = $(".navbar-default");
            var $logo = $(".logo").find("img");
            $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
            $logo.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
          });

        $(".navbar-toggle").on("click", function () {
            $(this).toggleClass("active");
        });
      });
})(jQuery, Drupal);